package launcher

import ui.Window

fun main(args: Array<String>) {
    val window = Window()
    window.isVisible = true
}
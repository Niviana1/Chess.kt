package model

import java.io.Serializable

enum class Team : Serializable {
    WHITE,
    BLACK
}
package network

import java.io.Serializable

data class Packet(val content: Any) : Serializable